function setup() {
  createCanvas(400, 400);
  background("lightgrey")

  textFont("Comic Sans MS");
  textSize(30)
  textAlign(CENTER,CENTER);

}

function draw(){
  text("Aprendendo JS na Alura",200,200)
}
